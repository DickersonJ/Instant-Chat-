from django.shortcuts import render, redirect
from django.contrib.auth.models import User, auth
from django.contrib import messages
from django.http import HttpResponse , JsonResponse
from django.contrib.auth.decorators import login_required
from .models import Profile
from .models import *
from django.contrib.auth import login


# Create your views here.

def index(request):
    return render(request, 'index.html')

def signup(request):

    if request.method == 'POST':
        username = request.POST['username']
        email = request.POST['email']
        password = request.POST['password']
        password2 = request.POST['password2']

        if password == password2:
            if User.objects.filter(email=email).exists():
                messages.info(request, 'Email déjà existant')
                return redirect('signup')
            elif User.objects.filter(username=username).exists():
                messages.info(request, "Nom d'utilsateur déja existant")
                return redirect('signup')
            else:
                user = User.objects.create_user(username=username, email=email, password=password)
                user.save()

                #log user in and redirect to settings page
                user_login = auth.authenticate(username=username, password=password)
                auth.login(request, user_login)

                #create a Profile object for the new user
                user_model = User.objects.get(username=username)
                new_profile = Profile.objects.create(user=user_model, id_user=user_model.id)
                new_profile.save()
                return redirect('login')
        else:
            messages.info(request, 'Mot de Passe')
            return redirect('login')
        
    else:
        return render(request, 'signup.html')
    
def logins(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']

        user = auth.authenticate(username=username, password=password)

        if user is not None:
            login(request, user)

            # Redirigez l'utilisateur vers la page d'accueil
            return redirect("/home")

        else:
            messages.error(request, "Nom d'utilisateur ou mot de passe invalide.")
            return redirect('login')
    else:
        return render(request, 'login.html')
    
    
    
@login_required
def chat_page(request):
    # Obtenir la liste des utilisateurs connectés
    users = User.objects.filter(is_active=True)

    # Créer un tableau des utilisateurs connectés
    connected_users = []
    for user in users:
        connected_users.append({
            "username": user.username,
            "is_online": user.is_active,
        })

    context = {
        "connected_users": connected_users,
    }
    return render(request, "chat.html", context)


def home (request):
    return render(request, 'home.html')


def room(request , room):
    username = request.GET.get('username')
    room_details = Room.objects.get(name=room)
    return render(request , 'room.html' , {
        'username' : username , 
        'room' : room ,
        'room_details' : room_details , 
    })


def checkview(request):
    room = request.POST['room_name']
    username = request.POST['username']

    if Room.objects.filter(name = room).exists():
        return redirect('/'+ room + '/?username=' + username)
    else: 
        new_room = Room.objects.create(name = room)
        new_room.save()
        return redirect('/'+ room +  '/?username=' + username)
    

def send(request):
    message = request.POST['message']
    username = request.POST['username']
    room_id = request.POST['room_id']

    new_message = Message.objects.create(value= message , user = username , room = room_id)
    new_message.save()
    return HttpResponse('Message envoyé avec succès')

def getMessages(request , room):
    room_details = Room.objects.get(name=room)
    messages = Message.objects.filter(room = room_details.id).order_by('date')
    return JsonResponse({"messages" :list(messages.values())})